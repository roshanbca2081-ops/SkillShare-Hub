
  # SkillShare Hub (Community)

  This is a code bundle for SkillShare Hub (Community). The original project is available at https://www.figma.com/design/glGhjKCiaWium6uNt1T5FN/SkillShare-Hub--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  