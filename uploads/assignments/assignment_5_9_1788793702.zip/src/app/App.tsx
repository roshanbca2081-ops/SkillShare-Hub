import { useState } from "react";

const P = "#4F46E5", S = "#7C3AED", A = "#06B6D4", BG = "#F8FAFC", DK = "#0F172A";
const G1 = `linear-gradient(135deg, ${P}, ${S})`;
const G2 = `linear-gradient(135deg, ${S}, ${A})`;
const GLASS = "rgba(255,255,255,0.72)";
const GLASS_BORDER = "rgba(255,255,255,0.6)";
const SHADOW = "0 8px 32px rgba(79,70,229,0.12)";
const SHADOW_LG = "0 20px 60px rgba(79,70,229,0.18)";
const R = "16px";

const FRAMES = [
  { id: "F01", label: "Landing Page", emoji: "🏠" },
  { id: "F02", label: "Login", emoji: "🔐" },
  { id: "F03", label: "Register", emoji: "📝" },
  { id: "F04", label: "Admin Dashboard", emoji: "⚙️" },
  { id: "F05", label: "Graduate Dashboard", emoji: "🎓" },
  { id: "F06", label: "Fresher Dashboard", emoji: "🌱" },
  { id: "F07", label: "Academic Fields", emoji: "📚" },
  { id: "F08", label: "Courses", emoji: "🎯" },
  { id: "F09", label: "Course Detail", emoji: "📖" },
  { id: "F10", label: "Mentor Search", emoji: "🔍" },
  { id: "F11", label: "Mentor Profile & Booking", emoji: "📅" },
  { id: "F12", label: "Video Session", emoji: "🎥" },
  { id: "F13", label: "Assignments", emoji: "📋" },
  { id: "F14", label: "Research Groups", emoji: "🔬" },
  { id: "F15", label: "Resume Builder", emoji: "📄" },
  { id: "F16", label: "Placement", emoji: "💼" },
  { id: "F17", label: "Certificates", emoji: "🏆" },
  { id: "F18", label: "Messages", emoji: "💬" },
  { id: "F19", label: "Notifications", emoji: "🔔" },
  { id: "F20", label: "Profile & Settings", emoji: "👤" },
];

const btnSt = (): React.CSSProperties => ({ background: G1, color: "#fff", border: "none", borderRadius: "10px", padding: "10px 22px", fontFamily: "'Poppins',sans-serif", fontWeight: 600, fontSize: "0.875rem", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "6px", boxShadow: "0 4px 14px rgba(79,70,229,.35)" });
const btnOut = (): React.CSSProperties => ({ background: "transparent", color: P, border: `2px solid ${P}`, borderRadius: "10px", padding: "8px 20px", fontFamily: "'Poppins',sans-serif", fontWeight: 600, fontSize: "0.875rem", cursor: "pointer" });
const cardSt = (e?: React.CSSProperties): React.CSSProperties => ({ background: GLASS, backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", border: `1px solid ${GLASS_BORDER}`, borderRadius: R, boxShadow: SHADOW, ...e });
const pillSt = (c = P): React.CSSProperties => ({ background: `${c}18`, color: c, borderRadius: "20px", padding: "3px 10px", fontSize: "0.7rem", fontWeight: 600 });
const inpSt = (): React.CSSProperties => ({ width: "100%", padding: "10px 14px", borderRadius: "10px", border: "1.5px solid rgba(79,70,229,0.18)", background: "#F8FAFC", fontFamily: "'Inter',sans-serif", fontSize: "0.875rem", outline: "none", boxSizing: "border-box" as const });

function Tag({ children, color = P }: { children: React.ReactNode; color?: string }) { return <span style={pillSt(color)}>{children}</span>; }
function Stars({ n = 5 }: { n?: number }) { return <span style={{ color: "#F59E0B", fontSize: "0.8rem" }}>{"★".repeat(n)}{"☆".repeat(5-n)}</span>; }
function Avatar({ name, size = 40 }: { name: string; size?: number }) { return <div style={{ width: size, height: size, borderRadius: "50%", background: G1, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: size*0.38, fontFamily: "'Poppins',sans-serif", flexShrink: 0 }}>{name[0]}</div>; }

function FrameNav({ current, setFrame }: { current: string; setFrame: (f: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ position: "fixed", left: 0, top: 0, bottom: 0, width: open ? 260 : 60, background: DK, zIndex: 1000, transition: "width .25s", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "4px 0 20px rgba(0,0,0,0.2)" }}>
      <div style={{ padding: "16px 12px", borderBottom: "1px solid rgba(255,255,255,.06)", display: "flex", alignItems: "center", gap: 10 }}>
        <button onClick={() => setOpen(!open)} style={{ background: "rgba(255,255,255,0.08)", border: "none", color: "#fff", borderRadius: 8, width: 36, height: 36, cursor: "pointer", fontSize: "1.1rem", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>{open ? "✕" : "☰"}</button>
        {open && <span style={{ color: "#94A3B8", fontSize: "0.7rem", fontWeight: 600, whiteSpace: "nowrap", letterSpacing: "0.08em" }}>FRAMES</span>}
      </div>
      <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", padding: "8px 0" }}>
        {FRAMES.map(f => (
          <button key={f.id} onClick={() => setFrame(f.id)} style={{ width: "100%", background: current === f.id ? `${P}22` : "none", border: "none", borderLeft: current === f.id ? `3px solid ${P}` : "3px solid transparent", color: current === f.id ? P : "#94A3B8", cursor: "pointer", padding: "10px 12px", display: "flex", alignItems: "center", gap: 10, transition: "all .15s", textAlign: "left", whiteSpace: "nowrap" }}>
            <span style={{ fontSize: "1rem", flexShrink: 0, width: 24, textAlign: "center" }}>{f.emoji}</span>
            {open && <div><div style={{ fontSize: "0.65rem", color: "#475569", fontWeight: 600 }}>{f.id}</div><div style={{ fontSize: "0.75rem", fontWeight: 600 }}>{f.label}</div></div>}
          </button>
        ))}
      </div>
    </div>
  );
}

function Navbar({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <nav style={{ position: "fixed", top: 16, left: "50%", transform: "translateX(-50%)", zIndex: 999, width: "min(92%,1200px)", background: "rgba(255,255,255,0.85)", backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)", border: "1px solid rgba(255,255,255,0.7)", borderRadius: "20px", boxShadow: "0 8px 40px rgba(79,70,229,0.14)", padding: "0 20px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => setFrame("F01")}><div style={{ width: 34, height: 34, background: G1, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🎓</div><span style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: "1rem", background: G1, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>ShareSkill Hub</span></div>
      <div style={{ display: "flex", gap: 4 }}>
        {[["Home","F01"],["Courses","F08"],["Mentors","F10"],["Research","F14"],["Placement","F16"]].map(([l,f]) => <button key={f} onClick={() => setFrame(f)} style={{ background: "none", border: "none", padding: "6px 10px", borderRadius: 8, cursor: "pointer", color: "#475569", fontWeight: 500, fontFamily: "'Inter',sans-serif", fontSize: "0.78rem" }}>{l}</button>)}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <button onClick={() => setFrame("F02")} style={btnOut()}>Login</button>
        <button onClick={() => setFrame("F03")} style={{ ...btnSt(), padding: "8px 16px" }}>Register</button>
        <button style={{ background: "none", border: "none", fontSize: "1.1rem", cursor: "pointer" }}>🌙</button>
      </div>
    </nav>
  );
}

function Sidebar({ role, active, setFrame }: { role: "admin"|"graduate"|"fresher"; active: string; setFrame: (f: string) => void }) {
  const nav: Record<string,[string,string,string][]> = {
    admin: [["⚡","Overview","F04"],["👥","Users","F04"],["📚","Courses","F08"],["🎓","Mentors","F10"],["📋","Assignments","F13"],["🔬","Research","F14"],["💼","Placement","F16"],["🏆","Certificates","F17"],["💬","Messages","F18"],["🔔","Notifs","F19"],["⚙️","Settings","F20"]],
    graduate: [["🏠","Dashboard","F05"],["📹","Sessions","F12"],["📚","Courses","F08"],["📋","Assignments","F13"],["🔬","Research","F14"],["💼","Placement","F16"],["🏆","Certificates","F17"],["💬","Messages","F18"],["👤","Profile","F20"]],
    fresher: [["🏠","Dashboard","F06"],["🔍","Find Mentors","F10"],["📚","Courses","F08"],["📹","Sessions","F12"],["📋","Assignments","F13"],["🔬","Research","F14"],["💼","Placement","F16"],["📄","Resume","F15"],["🏆","Certificates","F17"],["💬","Messages","F18"],["👤","Profile","F20"]],
  };
  const cl = { admin: "#EF4444", graduate: S, fresher: "#10B981" }[role];
  return (
    <div style={{ width: 220, background: DK, minHeight: "100vh", display: "flex", flexDirection: "column", flexShrink: 0 }}>
      <div style={{ padding: "20px 16px", borderBottom: "1px solid rgba(255,255,255,.06)", display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 32, height: 32, background: `linear-gradient(135deg, ${cl}, ${P})`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1rem" }}>{role==="admin"?"⚙️":role==="graduate"?"🎓":"🌱"}</div>
        <div><div style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.8rem" }}>ShareSkill Hub</div><div style={{ color: cl, fontSize: "0.65rem", fontWeight: 600, textTransform: "uppercase" }}>{role}</div></div>
      </div>
      <div style={{ flex: 1, padding: "12px 8px", overflowY: "auto" }}>
        {nav[role].map(([icon,label,frame]) => (
          <button key={label} onClick={() => setFrame(frame)} style={{ width: "100%", background: active===label?`${cl}22`:"none", border: "none", borderLeft: active===label?`3px solid ${cl}`:"3px solid transparent", color: active===label?"#fff":"#64748B", cursor: "pointer", padding: "9px 10px", display: "flex", alignItems: "center", gap: 10, borderRadius: "0 8px 8px 0", marginBottom: 2, textAlign: "left" }}>
            <span style={{ fontSize: "0.95rem" }}>{icon}</span><span style={{ fontSize: "0.78rem", fontWeight: 600, fontFamily: "'Inter',sans-serif" }}>{label}</span>
          </button>
        ))}
      </div>
      <div style={{ padding: "12px 16px", borderTop: "1px solid rgba(255,255,255,.06)" }}>
        <button onClick={() => setFrame("F01")} style={{ background: "none", border: "none", color: "#64748B", fontSize: "0.78rem", cursor: "pointer" }}>🚪 Logout</button>
      </div>
    </div>
  );
}

function KpiCard({ icon, label, value, sub, color }: { icon: string; label: string; value: string; sub: string; color: string }) {
  return (
    <div style={cardSt({ padding: "20px 18px" })}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ width: 40, height: 40, background: `${color}18`, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.2rem" }}>{icon}</div>
        <span style={{ fontSize: "0.7rem", color: "#10B981", fontWeight: 600 }}>↑ 12%</span>
      </div>
      <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: "1.6rem", color: DK }}>{value}</div>
      <div style={{ fontWeight: 600, fontSize: "0.82rem", color: DK, marginBottom: 2 }}>{label}</div>
      <div style={{ color: "#64748B", fontSize: "0.72rem" }}>{sub}</div>
    </div>
  );
}

/* F01 */
function F01({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <div style={{ background: BG, minHeight: "100vh" }}>
      <section style={{ minHeight: "100vh", background: "linear-gradient(160deg,#EEF2FF,#F8FAFC 40%,#E0F2FE)", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", textAlign: "center", padding: "100px 24px 60px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: "10%", left: "5%", width: 400, height: 400, background: `radial-gradient(circle,${P}18,transparent 70%)`, borderRadius: "50%", pointerEvents: "none" }} />
        <div style={{ position: "absolute", bottom: "10%", right: "5%", width: 300, height: 300, background: `radial-gradient(circle,${A}20,transparent 70%)`, borderRadius: "50%", pointerEvents: "none" }} />
        <div style={{ ...pillSt(A), marginBottom: 16, fontSize: "0.8rem", padding: "6px 16px" }}>🚀 India's #1 Peer Mentorship Platform</div>
        <h1 style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 900, lineHeight: 1.15, marginBottom: 20, maxWidth: 780 }}>Connect with <span style={{ background: G1, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Graduate Mentors</span><br />Accelerate Your Academic Journey</h1>
        <p style={{ fontSize: "1.1rem", color: "#475569", maxWidth: 620, lineHeight: 1.7, marginBottom: 36 }}>ShareSkill Hub bridges the gap between freshers and experienced graduates — mentorship in academics, research, placements, assignments, and live video sessions.</p>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", justifyContent: "center" }}>
          <button onClick={() => setFrame("F03")} style={{ ...btnSt(), padding: "14px 32px", fontSize: "1rem", borderRadius: 12, boxShadow: "0 8px 28px rgba(79,70,229,.45)" }}>Get Started Free →</button>
          <button onClick={() => setFrame("F10")} style={{ ...btnOut(), padding: "12px 28px", fontSize: "1rem", borderRadius: 12 }}>Find a Mentor</button>
        </div>
        <div style={cardSt({ padding: "10px 20px", marginTop: 48, display: "flex", gap: 24, flexWrap: "wrap", justifyContent: "center" })}>
          {[["12K+","Active Mentors","🎓"],["58K+","Students Helped","🌱"],["96K+","Sessions Done","📹"],["4.9★","Avg. Rating","⭐"]].map(([n,l,ic]) => (
            <div key={l} style={{ textAlign: "center" }}>
              <div style={{ fontSize: "2rem" }}>{ic}</div>
              <div style={{ fontSize: "1.8rem", fontFamily: "'Poppins',sans-serif", fontWeight: 800, background: G1, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{n}</div>
              <div style={{ fontSize: "0.78rem", color: "#64748B" }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      <section style={{ padding: "80px 24px", background: "#fff" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ ...pillSt(S), display: "inline-block", marginBottom: 12 }}>📚 Academic Fields</div>
            <h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Explore by Your Field of Study</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", gap: 18 }}>
            {[["💻","Computer Science",320,P],["🔬","Life Sciences",185,S],["⚡","Electrical Eng.",142,A],["🧮","Mathematics",98,"#F59E0B"],["🏗️","Civil Engg.",76,"#10B981"],["🧪","Chemistry",64,"#EF4444"]].map(([ic,n,c,col]) => (
              <div key={n} onClick={() => setFrame("F07")} style={cardSt({ padding: "28px 20px", textAlign: "center", cursor: "pointer" })}>
                <div style={{ fontSize: "2.4rem", marginBottom: 10 }}>{ic}</div>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.9rem", color: DK, marginBottom: 4 }}>{n}</div>
                <div style={{ ...pillSt(col as string), fontSize: "0.68rem" }}>{c} mentors</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "80px 24px", background: "linear-gradient(135deg,#EEF2FF,#F0F9FF)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}><div style={{ ...pillSt(P), display: "inline-block", marginBottom: 12 }}>✨ Platform Features</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Everything You Need to Succeed</h2></div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 24 }}>
            {[["🎓","Expert Mentors","Connect with experienced graduates from top universities and companies."],["📹","Live Video Sessions","Schedule 1-on-1 or group mentorship sessions with HD video calls."],["📝","Assignments & Feedback","Submit work, get detailed mentor feedback, and track progress."],["🔬","Research Collaboration","Join research groups, share papers, collaborate on projects."],["💼","Placement Guidance","Resume reviews, mock interviews, and placement cell connections."],["🏆","Verified Certificates","Earn blockchain-verified certificates for completed mentorships."]].map(([ic,t,d]) => (
              <div key={t} style={cardSt({ padding: "28px 24px" })}><div style={{ fontSize: "2rem", marginBottom: 12 }}>{ic}</div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "1rem", marginBottom: 8, color: DK }}>{t}</div><div style={{ color: "#64748B", fontSize: "0.875rem", lineHeight: 1.6 }}>{d}</div></div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "80px 24px", background: G1, color: "#fff", textAlign: "center" }}>
        <h2 style={{ fontFamily: "'Poppins',sans-serif", color: "#fff", marginBottom: 14 }}>Ready to Start Your Journey?</h2>
        <p style={{ opacity: 0.85, marginBottom: 32 }}>Join 58,000+ students already accelerating their careers</p>
        <div style={{ display: "flex", gap: 14, justifyContent: "center" }}>
          <button onClick={() => setFrame("F03")} style={{ background: "#fff", color: P, border: "none", borderRadius: 12, padding: "14px 32px", fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "1rem", cursor: "pointer" }}>Sign Up Free</button>
          <button onClick={() => setFrame("F08")} style={{ background: "rgba(255,255,255,.12)", color: "#fff", border: "1.5px solid rgba(255,255,255,.4)", borderRadius: 12, padding: "14px 28px", fontFamily: "'Poppins',sans-serif", fontWeight: 600, cursor: "pointer" }}>Browse Courses</button>
        </div>
      </section>

      <footer style={{ background: DK, color: "#94A3B8", padding: "60px 24px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 40, marginBottom: 48 }}>
            <div><div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 14 }}><div style={{ width: 34, height: 34, background: G1, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>🎓</div><span style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: "#fff" }}>ShareSkill Hub</span></div><p style={{ fontSize: "0.85rem", lineHeight: 1.7 }}>Bridging the gap between freshers and experienced graduates through peer-led mentorship.</p></div>
            {[{h:"Platform",l:["Courses","Mentors","Research","Placement","Certificates"]},{h:"Company",l:["About Us","Blog","Careers","Press","Contact"]},{h:"Support",l:["Help Center","Terms","Privacy","Cookie Policy","Sitemap"]}].map(col => (
              <div key={col.h}><div style={{ color: "#fff", fontWeight: 700, marginBottom: 14, fontFamily: "'Poppins',sans-serif" }}>{col.h}</div>{col.l.map(l => <div key={l} style={{ marginBottom: 8, fontSize: "0.82rem", cursor: "pointer" }}>{l}</div>)}</div>
            ))}
          </div>
          <div style={{ borderTop: "1px solid rgba(255,255,255,.06)", paddingTop: 20, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10, fontSize: "0.78rem" }}>
            <span>© 2025 ShareSkill Hub. All rights reserved.</span><span>Made with ❤️ for Students of India</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* F02 */
function F02({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#4F46E5,#7C3AED,#06B6D4)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      {["🎓","📚","💡","🔬","💻","✏️"].map((ic,i) => <div key={i} style={{ position: "fixed", fontSize: `${2+(i%3)}rem`, opacity: 0.1, top: `${15+i*13}%`, left: `${5+i*15}%`, filter: "blur(1px)", pointerEvents: "none" }}>{ic}</div>)}
      <div style={cardSt({ padding: "48px 40px", width: "100%", maxWidth: 460, boxShadow: SHADOW_LG })}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ width: 56, height: 56, background: G1, borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.8rem", margin: "0 auto 14px" }}>🎓</div>
          <h2 style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: DK, marginBottom: 4 }}>Welcome Back!</h2>
          <p style={{ color: "#64748B", fontSize: "0.875rem" }}>Sign in to continue your learning journey</p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div><label style={{ display: "block", marginBottom: 6, color: DK, fontWeight: 600, fontSize: "0.82rem" }}>Email Address</label><input style={inpSt()} placeholder="you@example.com" type="email" /></div>
          <div><label style={{ display: "block", marginBottom: 6, color: DK, fontWeight: 600, fontSize: "0.82rem" }}>Password</label><input style={inpSt()} placeholder="••••••••" type="password" /></div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <label style={{ display: "flex", gap: 6, alignItems: "center", cursor: "pointer", fontSize: "0.8rem", color: "#64748B" }}><input type="checkbox" /> Remember me</label>
            <span style={{ color: P, fontSize: "0.8rem", cursor: "pointer", fontWeight: 600 }}>Forgot Password?</span>
          </div>
          <button onClick={() => setFrame("F06")} style={{ ...btnSt(), justifyContent: "center", padding: "13px", fontSize: "0.95rem", borderRadius: 12 }}>Sign In →</button>
          <div style={{ textAlign: "center", color: "#94A3B8", fontSize: "0.8rem" }}>or continue with</div>
          <button style={{ background: "#fff", color: "#374151", border: "1.5px solid #E2E8F0", borderRadius: 10, padding: "10px", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, fontFamily: "'Inter',sans-serif", fontWeight: 600, fontSize: "0.875rem", cursor: "pointer" }}>🔵 Continue with Google</button>
          <button style={{ background: "#1877F2", color: "#fff", border: "none", borderRadius: 10, padding: "10px", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, fontFamily: "'Inter',sans-serif", fontWeight: 600, fontSize: "0.875rem", cursor: "pointer" }}>🔷 Continue with Facebook</button>
        </div>
        <p style={{ textAlign: "center", marginTop: 24, fontSize: "0.85rem", color: "#64748B" }}>New to ShareSkill Hub? <span onClick={() => setFrame("F03")} style={{ color: P, fontWeight: 700, cursor: "pointer" }}>Create Account</span></p>
      </div>
    </div>
  );
}

/* F03 */
function F03({ setFrame }: { setFrame: (f: string) => void }) {
  const [role, setRole] = useState<"fresher"|"graduate">("fresher");
  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#7C3AED,#4F46E5,#06B6D4)", display: "flex", alignItems: "center", justifyContent: "center", padding: "80px 24px" }}>
      <div style={cardSt({ padding: "48px 40px", width: "100%", maxWidth: 560, boxShadow: SHADOW_LG })}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 52, height: 52, background: G2, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.6rem", margin: "0 auto 12px" }}>📝</div>
          <h2 style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: DK, marginBottom: 4 }}>Join ShareSkill Hub</h2>
          <p style={{ color: "#64748B", fontSize: "0.875rem" }}>Start your mentorship journey today!</p>
        </div>
        <div style={{ display: "flex", gap: 10, marginBottom: 24, background: "#F1F5F9", padding: 4, borderRadius: 12 }}>
          {(["fresher","graduate"] as const).map(r => <button key={r} onClick={() => setRole(r)} style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", fontFamily: "'Poppins',sans-serif", fontWeight: 600, fontSize: "0.875rem", cursor: "pointer", background: role===r?G1:"transparent", color: role===r?"#fff":"#64748B" }}>{r==="fresher"?"🌱 I'm a Fresher":"🎓 I'm a Graduate"}</button>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          {[{l:"First Name",p:"Priya"},{l:"Last Name",p:"Sharma"},{l:"Email Address",p:"priya@example.com",full:true},{l:"Phone Number",p:"+91 98765 43210"},{l:role==="graduate"?"Company / University":"College",p:role==="graduate"?"IIT Delhi":"Delhi University"},{l:role==="graduate"?"Area of Expertise":"Year of Study",p:role==="graduate"?"CS, ML, DSA...":"1st Year"},{l:"Password",p:"••••••••",t:"password"},{l:"Confirm Password",p:"••••••••",t:"password"}].map(f => (
            <div key={f.l} style={{ gridColumn: (f as any).full ? "1/-1" : "auto" }}>
              <label style={{ display: "block", marginBottom: 5, color: DK, fontWeight: 600, fontSize: "0.78rem" }}>{f.l}</label>
              <input style={inpSt()} placeholder={f.p} type={(f as any).t || "text"} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginTop: 16, marginBottom: 20 }}>
          <input type="checkbox" style={{ accentColor: P, marginTop: 2 }} />
          <span style={{ fontSize: "0.78rem", color: "#64748B" }}>I agree to the <span style={{ color: P, fontWeight: 600 }}>Terms of Service</span> and <span style={{ color: P, fontWeight: 600 }}>Privacy Policy</span></span>
        </div>
        <button onClick={() => setFrame(role==="fresher"?"F06":"F05")} style={{ ...btnSt(), width: "100%", justifyContent: "center", padding: "13px", fontSize: "0.95rem", borderRadius: 12 }}>Create {role==="fresher"?"Fresher":"Mentor"} Account →</button>
        <p style={{ textAlign: "center", marginTop: 20, fontSize: "0.85rem", color: "#64748B" }}>Already have an account? <span onClick={() => setFrame("F02")} style={{ color: P, fontWeight: 700, cursor: "pointer" }}>Sign In</span></p>
      </div>
    </div>
  );
}

/* F04 */
function F04({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: BG }}>
      <Sidebar role="admin" active="Overview" setFrame={setFrame} />
      <main style={{ flex: 1, padding: "32px 28px", overflow: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 28 }}><div><h2 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 4 }}>Admin Overview</h2><p style={{ color: "#64748B", fontSize: "0.875rem" }}>Platform health and key metrics</p></div><Avatar name="Admin" size={38} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
          <KpiCard icon="👥" label="Total Users" value="71,240" sub="+1,840 this week" color={P} />
          <KpiCard icon="🎓" label="Active Mentors" value="12,480" sub="480 new this month" color={S} />
          <KpiCard icon="📹" label="Sessions Today" value="3,291" sub="Live: 142" color={A} />
          <KpiCard icon="💰" label="Revenue (Month)" value="₹8.4L" sub="Monthly recurring" color="#F59E0B" />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18 }}>
          <div style={cardSt({ padding: "20px" })}>
            <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, marginBottom: 16, color: DK }}>Recent Registrations</div>
            {[{n:"Priya S.",e:"priya@gmail.com",r:"Graduate",s:"Pending"},{n:"Rahul K.",e:"rahul@gmail.com",r:"Fresher",s:"Active"},{n:"Ananya M.",e:"ananya@gmail.com",r:"Graduate",s:"Active"},{n:"Dev P.",e:"dev@gmail.com",r:"Fresher",s:"Active"}].map(u => (
              <div key={u.e} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                <Avatar name={u.n} size={32} />
                <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: "0.82rem", color: DK }}>{u.n}</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>{u.e}</div></div>
                <Tag color={u.r==="Graduate"?S:"#10B981"}>{u.r}</Tag>
                <Tag color={u.s==="Pending"?"#F59E0B":"#10B981"}>{u.s}</Tag>
              </div>
            ))}
          </div>
          <div style={cardSt({ padding: "20px" })}>
            <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, marginBottom: 16, color: DK }}>Quick Actions</div>
            {[["Approve Pending Mentors","🎓",S],["Review Reported Content","⚠️","#EF4444"],["Send Notification","📢",A],["Generate Report","📊","#F59E0B"],["Manage Certificates","🏆","#10B981"]].map(([l,i,c]) => (
              <button key={l} style={{ width: "100%", background: `${c}10`, border: "none", borderRadius: 10, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10, cursor: "pointer", marginBottom: 8, textAlign: "left" }}>
                <span style={{ fontSize: "1rem" }}>{i}</span><span style={{ fontSize: "0.8rem", fontWeight: 600, color: c as string }}>{l}</span>
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

/* F05 */
function F05({ setFrame }: { setFrame: (f: string) => void }) {
  const sC: Record<string,string> = { Approved: "#10B981", Pending: "#F59E0B", Scheduled: P, Rejected: "#EF4444" };
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: BG }}>
      <Sidebar role="graduate" active="Dashboard" setFrame={setFrame} />
      <main style={{ flex: 1, padding: "32px 28px", overflow: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 28 }}><div><h2 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 4 }}>Graduate Dashboard</h2><p style={{ color: "#64748B", fontSize: "0.875rem" }}>Manage your mentorship profile and sessions</p></div><Avatar name="Priya Sharma" size={38} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
          <KpiCard icon="📹" label="Total Sessions" value="248" sub="12 this week" color={P} />
          <KpiCard icon="🌱" label="Students Helped" value="186" sub="Across 8 fields" color={S} />
          <KpiCard icon="⭐" label="Avg. Rating" value="4.94" sub="186 reviews" color="#F59E0B" />
          <KpiCard icon="💰" label="Earnings (Month)" value="₹24,800" sub="32 sessions" color="#10B981" />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18 }}>
          <div style={cardSt({ padding: "20px" })}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>Upcoming Bookings</div><button onClick={() => setFrame("F11")} style={{ ...btnSt(), padding: "6px 14px", fontSize: "0.78rem" }}>Manage All</button></div>
            {[{s:"Rahul K.",t:"DSA Interview Prep",tm:"Today, 4:00 PM",st:"Approved"},{s:"Ananya M.",t:"Resume Review",tm:"Tomorrow, 11 AM",st:"Pending"},{s:"Dev P.",t:"Research Guidance",tm:"Thu, 3 PM",st:"Scheduled"}].map(b => (
              <div key={b.s} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                <Avatar name={b.s} size={36} />
                <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: "0.85rem", color: DK }}>{b.s}</div><div style={{ fontSize: "0.75rem", color: "#64748B" }}>{b.t} · {b.tm}</div></div>
                <Tag color={sC[b.st]}>{b.st}</Tag>
                <div style={{ display: "flex", gap: 6 }}>
                  <button style={{ background: "#10B98118", border: "none", borderRadius: 6, padding: "5px 10px", cursor: "pointer", fontSize: "0.72rem", fontWeight: 600, color: "#10B981" }}>✓</button>
                  <button style={{ background: "#EF444418", border: "none", borderRadius: 6, padding: "5px 10px", cursor: "pointer", fontSize: "0.72rem", fontWeight: 600, color: "#EF4444" }}>✕</button>
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={cardSt({ padding: "18px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12 }}>Profile Completeness</div>
              <div style={{ height: 8, background: "#EEF2FF", borderRadius: 4, overflow: "hidden", marginBottom: 8 }}><div style={{ width: "88%", height: "100%", background: G1, borderRadius: 4 }} /></div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.78rem", color: "#64748B" }}><span>88% complete</span><span style={{ color: P, fontWeight: 600 }}>Improve</span></div>
            </div>
            <div style={cardSt({ padding: "18px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12 }}>Weekly Sessions</div>
              {["Mon","Tue","Wed","Thu","Fri"].map((d,i) => <div key={d} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}><span style={{ width: 28, fontSize: "0.72rem", color: "#64748B" }}>{d}</span><div style={{ flex: 1, height: 6, background: "#EEF2FF", borderRadius: 3, overflow: "hidden" }}><div style={{ width: `${[80,60,100,40,70][i]}%`, height: "100%", background: G1, borderRadius: 3 }} /></div><span style={{ fontSize: "0.68rem", color: "#64748B" }}>{[4,3,5,2,3][i]}h</span></div>)}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

/* F06 */
function F06({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: BG }}>
      <Sidebar role="fresher" active="Dashboard" setFrame={setFrame} />
      <main style={{ flex: 1, padding: "32px 28px", overflow: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 28 }}><div><h2 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 4 }}>Welcome back, Rahul! 👋</h2><p style={{ color: "#64748B" }}>Continue your learning journey</p></div><Avatar name="Rahul Kumar" size={38} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
          <KpiCard icon="📹" label="Sessions Done" value="14" sub="3 this week" color={P} />
          <KpiCard icon="📋" label="Assignments" value="8/12" sub="4 pending" color={S} />
          <KpiCard icon="📚" label="Courses Enrolled" value="3" sub="1 completed" color={A} />
          <KpiCard icon="🏆" label="Certificates" value="2" sub="1 pending" color="#F59E0B" />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "3fr 2fr", gap: 18 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>Current Courses</div><button onClick={() => setFrame("F08")} style={{ fontSize: "0.78rem", color: P, background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Browse More →</button></div>
              {[{t:"Data Structures & Algorithms",m:"Priya Sharma",p:68,c:P},{t:"Machine Learning Fundamentals",m:"Arjun Mehta",p:42,c:S},{t:"Research Methodology",m:"Dr. Kavita",p:91,c:A}].map(c => (
                <div key={c.t} style={{ marginBottom: 16 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><div><div style={{ fontWeight: 600, fontSize: "0.85rem", color: DK }}>{c.t}</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>by {c.m}</div></div><span style={{ fontWeight: 700, color: c.c }}>{c.p}%</span></div>
                  <div style={{ height: 6, background: "#EEF2FF", borderRadius: 3, overflow: "hidden" }}><div style={{ width: `${c.p}%`, height: "100%", background: G1, borderRadius: 3 }} /></div>
                </div>
              ))}
            </div>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>Upcoming Sessions</div>
              {[{m:"Priya Sharma",t:"DSA Review",tm:"Today 4:00 PM"},{m:"Arjun Mehta",t:"ML Project",tm:"Tomorrow 11 AM"}].map(s => (
                <div key={s.m} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: "1px solid rgba(0,0,0,.05)", alignItems: "center" }}>
                  <div style={{ width: 40, height: 40, background: `${P}18`, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>📹</div>
                  <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: "0.85rem", color: DK }}>{s.t}</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>with {s.m} · {s.tm}</div></div>
                  <button onClick={() => setFrame("F12")} style={{ ...btnSt(), padding: "6px 14px", fontSize: "0.75rem" }}>Join</button>
                </div>
              ))}
              <button onClick={() => setFrame("F10")} style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 12, padding: "10px", fontSize: "0.8rem" }}>+ Book New Session</button>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={cardSt({ padding: "18px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>Pending Assignments</div>
              {[{t:"Binary Trees – Problem Set",d:"Due Tomorrow",s:"Urgent"},{t:"Linear Regression Report",d:"Due in 3 days",s:"On Track"},{t:"Research Proposal Draft",d:"Due in 1 week",s:"On Track"}].map(a => (
                <div key={a.t} style={{ padding: "10px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                  <div style={{ fontWeight: 600, fontSize: "0.82rem", color: DK, marginBottom: 4 }}>{a.t}</div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ fontSize: "0.72rem", color: "#64748B" }}>{a.d}</span><Tag color={a.s==="Urgent"?"#EF4444":"#10B981"}>{a.s}</Tag></div>
                </div>
              ))}
              <button onClick={() => setFrame("F13")} style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 12, padding: "8px", fontSize: "0.78rem" }}>View All</button>
            </div>
            <div style={{ ...cardSt({ padding: "18px" }), background: G1, border: "none" }}>
              <div style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, marginBottom: 8 }}>🚀 Quick Actions</div>
              {[["🔍 Find a Mentor","F10"],["📄 Build Resume","F15"],["🔬 Join Research Group","F14"],["💼 Placement Guide","F16"]].map(([l,f]) => (
                <button key={l} onClick={() => setFrame(f)} style={{ width: "100%", background: "rgba(255,255,255,.15)", border: "1px solid rgba(255,255,255,.25)", borderRadius: 8, padding: "8px 12px", color: "#fff", fontFamily: "'Inter',sans-serif", fontWeight: 600, fontSize: "0.78rem", cursor: "pointer", marginBottom: 8, textAlign: "left" }}>{l}</button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

/* F07 */
function F07({ setFrame }: { setFrame: (f: string) => void }) {
  const fields = [["💻","Computer Science & IT",["Programming","DSA","AI/ML"],3240,P],["🔬","Life Sciences & Biotech",["Biology","Genetics","Biochemistry"],1850,S],["⚡","Electrical Engineering",["Circuit Design","VLSI","Power Systems"],1420,A],["🧮","Mathematics & Statistics",["Calculus","Probability","Linear Algebra"],980,"#F59E0B"],["🏗️","Civil Engineering",["Structural","Transportation","Environmental"],760,"#10B981"],["🧪","Chemistry & Materials",["Organic","Inorganic","Physical Chem"],640,"#EF4444"],["📊","Business & Management",["Finance","Marketing","Strategy"],1120,"#8B5CF6"],["🔭","Physics & Astronomy",["Quantum","Astrophysics"],520,"#06B6D4"],["⚕️","Medical Sciences",["Anatomy","Pharmacology","Public Health"],890,"#EC4899"],["🏛️","Law & Social Sciences",["Constitutional","Criminal","Sociology"],430,"#F97316"],["🎨","Design & Architecture",["UI/UX","Interior","Product Design"],680,"#14B8A6"],["🌍","Environmental Science",["Ecology","Climate Science","Geography"],340,"#22C55E"]];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{ ...pillSt(P), display: "inline-block", marginBottom: 12 }}>📚 Academic Fields</div>
          <h2 style={{ fontFamily: "'Poppins',sans-serif" }}>250+ Disciplines, 12,000+ Mentors</h2>
          <p style={{ color: "#64748B", marginTop: 8, marginBottom: 24 }}>Find mentorship in your exact field of study</p>
          <input style={{ ...inpSt(), width: 360, borderRadius: 30, padding: "12px 20px" }} placeholder="🔍  Search academic fields..." />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 20 }}>
          {fields.map(([ic,n,subs,cnt,col]) => (
            <div key={n as string} onClick={() => setFrame("F10")} style={cardSt({ padding: "24px", cursor: "pointer" })}>
              <div style={{ display: "flex", gap: 14, marginBottom: 14, alignItems: "flex-start" }}>
                <div style={{ width: 50, height: 50, background: `${col}18`, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.5rem", flexShrink: 0 }}>{ic}</div>
                <div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.9rem", color: DK, marginBottom: 4 }}>{n as string}</div><div style={{ ...pillSt(col as string), fontSize: "0.68rem" }}>{(cnt as number).toLocaleString()} mentors</div></div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {(subs as string[]).map(s => <span key={s} style={{ background: "#F1F5F9", color: "#475569", borderRadius: 20, padding: "3px 8px", fontSize: "0.68rem" }}>{s}</span>)}
              </div>
              <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: "0.75rem", color: "#64748B" }}>₹800–₹2,400/hr</span>
                <button style={{ background: `${col}18`, border: "none", borderRadius: 8, padding: "6px 12px", color: col as string, fontWeight: 600, fontSize: "0.75rem", cursor: "pointer" }}>Explore →</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* F08 */
function F08({ setFrame }: { setFrame: (f: string) => void }) {
  const [filter, setFilter] = useState("All");
  const cats = ["All","CS & IT","Mathematics","Life Sciences","Engineering","Business","Design"];
  const courses = [
    {t:"Data Structures & Algorithms",m:"Priya Sharma",r:4.9,s:4820,p:1200,d:"48h",l:"Intermediate",tag:"Bestseller",c:P},
    {t:"Machine Learning A-Z",m:"Arjun Mehta",r:4.8,s:3910,p:1500,d:"56h",l:"Advanced",tag:"Trending",c:S},
    {t:"Research Methodology 101",m:"Dr. Kavita Nair",r:4.7,s:2140,p:900,d:"32h",l:"Beginner",tag:"New",c:A},
    {t:"VLSI Design Fundamentals",m:"Dr. Rahul Gupta",r:4.8,s:1680,p:1800,d:"44h",l:"Advanced",tag:"",c:"#F59E0B"},
    {t:"Statistical Analysis with Python",m:"Sneha Iyer",r:4.6,s:2890,p:1100,d:"38h",l:"Intermediate",tag:"Popular",c:"#10B981"},
    {t:"UI/UX for Engineers",m:"Rohan Desai",r:4.9,s:3240,p:800,d:"28h",l:"Beginner",tag:"Hot",c:"#EC4899"},
  ];
  const tC: Record<string,string> = {Bestseller:P,Trending:S,New:A,Popular:"#10B981",Hot:"#EF4444"};
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div><div style={{ ...pillSt(P), display: "inline-block", marginBottom: 10 }}>🎯 Courses</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>4,280+ Expert-Led Courses</h2><p style={{ color: "#64748B" }}>Created by top graduate mentors</p></div>
          <input style={{ ...inpSt(), width: 240, borderRadius: 30 }} placeholder="🔍 Search courses..." />
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
          {cats.map(c => <button key={c} onClick={() => setFilter(c)} style={{ padding: "7px 16px", borderRadius: 20, border: filter===c?"none":"1.5px solid #E2E8F0", background: filter===c?G1:"#fff", color: filter===c?"#fff":"#64748B", fontWeight: 600, fontSize: "0.8rem", cursor: "pointer" }}>{c}</button>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 22 }}>
          {courses.map(c => (
            <div key={c.t} onClick={() => setFrame("F09")} style={{ background: "#fff", borderRadius: 18, overflow: "hidden", boxShadow: SHADOW, cursor: "pointer" }}>
              <div style={{ height: 160, background: `linear-gradient(135deg,${c.c}40,${c.c}80)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "3rem", position: "relative" }}>
                📚
                {c.tag && <span style={{ position: "absolute", top: 12, left: 12, ...pillSt(tC[c.tag]||P) }}>{c.tag}</span>}
                <span style={{ position: "absolute", top: 12, right: 12, ...pillSt("#fff"), color: DK }}>{c.l}</span>
              </div>
              <div style={{ padding: "18px 20px" }}>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.95rem", color: DK, marginBottom: 6, lineHeight: 1.4 }}>{c.t}</div>
                <div style={{ fontSize: "0.78rem", color: "#64748B", marginBottom: 10 }}>by {c.m}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}><Stars n={Math.round(c.r)} /><span style={{ fontSize: "0.75rem", color: "#64748B" }}>{c.r} ({c.s.toLocaleString()})</span></div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div><span style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: "1.1rem", color: DK }}>₹{c.p.toLocaleString()}</span><span style={{ fontSize: "0.72rem", color: "#64748B", marginLeft: 6 }}>{c.d}</span></div>
                  <button style={{ ...btnSt(), padding: "6px 14px", fontSize: "0.75rem" }}>Enroll</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* F09 */
function F09({ setFrame }: { setFrame: (f: string) => void }) {
  return (
    <div style={{ background: BG, minHeight: "100vh" }}>
      <div style={{ background: `linear-gradient(160deg,${DK},#1E293B)`, padding: "100px 24px 60px", color: "#fff" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "2fr 1fr", gap: 40, alignItems: "start" }}>
          <div>
            <div style={{ display: "flex", gap: 8, marginBottom: 16 }}><Tag color={A}>Bestseller</Tag><Tag color={P}>Intermediate</Tag></div>
            <h1 style={{ fontFamily: "'Poppins',sans-serif", color: "#fff", marginBottom: 14 }}>Data Structures & Algorithms — Complete Masterclass 2025</h1>
            <p style={{ color: "#94A3B8", lineHeight: 1.7, marginBottom: 18 }}>Master 50+ algorithms, ace DSA interviews at FAANG. 200+ practice problems with solutions.</p>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 18, fontSize: "0.85rem", color: "#94A3B8" }}><span>⭐ 4.9 (4,820 ratings)</span><span>👥 12,400 students</span><span>⏱ 48 hours</span></div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}><Avatar name="Priya Sharma" size={44} /><span style={{ color: "#CBD5E1" }}>Created by <span style={{ color: A, fontWeight: 600 }}>Priya Sharma</span> — SDE @ Google</span></div>
          </div>
          <div style={cardSt({ padding: "28px", background: "rgba(255,255,255,0.96)" })}>
            <div style={{ height: 160, background: `linear-gradient(135deg,${P}30,${S}40)`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "4rem", marginBottom: 16 }}>📊</div>
            <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 900, fontSize: "2rem", color: DK }}>₹1,200</div>
            <div style={{ color: "#94A3B8", textDecoration: "line-through", marginBottom: 14 }}>₹4,999</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
              <button onClick={() => setFrame("F06")} style={{ ...btnSt(), flex: 1, justifyContent: "center", padding: "12px" }}>Enroll Now</button>
              <button onClick={() => setFrame("F12")} style={{ ...btnOut(), padding: "12px 14px" }}>📹</button>
            </div>
            {["📹 48 hours on-demand video","📋 50+ assignments & quizzes","📄 Certificate of completion","♾️ Lifetime access"].map(f => <div key={f} style={{ fontSize: "0.8rem", color: "#475569", marginBottom: 6 }}>{f}</div>)}
            <button onClick={() => setFrame("F11")} style={{ ...btnOut(), width: "100%", marginTop: 14, padding: "10px", textAlign: "center" }}>Book 1-on-1 Mentor Session</button>
          </div>
        </div>
      </div>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div style={cardSt({ padding: "20px" })}>
            <h4 style={{ fontFamily: "'Poppins',sans-serif", marginBottom: 14, color: DK }}>What You will Learn</h4>
            {["Arrays, Strings, Linked Lists, Trees","Dynamic Programming & Greedy Algorithms","Graph Algorithms (BFS, DFS, Dijkstra)","Sorting: Quick, Merge, Heap Sort","200+ LeetCode Problems with Solutions","FAANG Interview Strategy & Tips"].map(l => <div key={l} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: "0.82rem", color: "#475569" }}><span style={{ color: "#10B981", fontWeight: 700 }}>✓</span>{l}</div>)}
          </div>
          <div style={cardSt({ padding: "20px" })}>
            <h4 style={{ fontFamily: "'Poppins',sans-serif", marginBottom: 12, color: DK }}>Curriculum</h4>
            {["Section 1: Arrays & Strings — 6 lessons","Section 2: Linked Lists — 7 lessons","Section 3: Stacks & Queues — 5 lessons","Section 4: Trees & Graphs — 8 lessons","Section 5: Dynamic Programming — 9 lessons","Section 6: System Design — 6 lessons"].map(s => <div key={s} style={{ padding: "8px 0", borderBottom: "1px solid rgba(0,0,0,.05)", fontSize: "0.8rem", color: "#475569" }}>▶ {s}</div>)}
          </div>
        </div>
      </div>
    </div>
  );
}

/* F10 */
function F10({ setFrame }: { setFrame: (f: string) => void }) {
  const mentors = [
    {n:"Priya Sharma",r:"SDE @ Google",f:"CS",sk:["DSA","System Design","Java"],rt:4.94,ss:248,p:1200,av:"Available today"},
    {n:"Arjun Mehta",r:"Data Scientist @ Meta",f:"AI/ML",sk:["Python","TensorFlow","Statistics"],rt:4.88,ss:193,p:1500,av:"Tomorrow"},
    {n:"Dr. Kavita Nair",r:"Researcher @ IISc",f:"Biotech",sk:["Research Methods","CRISPR","Bioinformatics"],rt:4.91,ss:156,p:1800,av:"Available today"},
    {n:"Rahul Gupta",r:"VLSI Engineer @ Qualcomm",f:"EE",sk:["VLSI","Verilog","Circuit Design"],rt:4.76,ss:89,p:1400,av:"In 2 days"},
  ];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={cardSt({ padding: "32px", marginBottom: 28, background: `linear-gradient(135deg,${P}10,${S}08)` })}>
          <h2 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 6 }}>🔍 Find Your Perfect Mentor</h2>
          <p style={{ color: "#64748B", marginBottom: 20 }}>Search by field, skill, language, or availability</p>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr auto", gap: 12 }}>
            <input style={{ ...inpSt(), borderRadius: 12 }} placeholder="🔍  Search by name, skill, or field..." />
            <select style={inpSt()}><option>All Fields</option><option>Computer Science</option><option>AI/ML</option><option>Life Sciences</option></select>
            <select style={inpSt()}><option>Any Price</option><option>Under ₹800</option><option>₹800-₹1500</option><option>₹1500+</option></select>
            <select style={inpSt()}><option>Availability</option><option>Available Today</option><option>This Week</option></select>
            <button style={{ ...btnSt(), padding: "10px 20px", borderRadius: 12, whiteSpace: "nowrap" }}>Search</button>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: 22 }}>
          <div style={cardSt({ padding: "20px", alignSelf: "start" })}>
            <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 16, fontSize: "0.9rem" }}>Filters</div>
            {[["Rating",["4.5+","4.0+","Any"]],["Language",["English","Hindi","Tamil","Telugu"]],["Session Type",["Video Call","Voice Call","Group"]],["Experience",["1-2 years","3-5 years","5+ years"]]].map(([lbl,opts]) => (
              <div key={lbl as string} style={{ marginBottom: 20 }}>
                <div style={{ fontWeight: 700, fontSize: "0.8rem", color: DK, marginBottom: 10 }}>{lbl as string}</div>
                {(opts as string[]).map(o => <label key={o} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7, cursor: "pointer", fontSize: "0.8rem", color: "#475569" }}><input type="checkbox" style={{ accentColor: P }} />{o}</label>)}
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {mentors.map(m => (
              <div key={m.n} style={{ background: "#fff", borderRadius: 18, padding: "22px 24px", boxShadow: SHADOW, display: "flex", gap: 20, alignItems: "flex-start", cursor: "pointer" }} onClick={() => setFrame("F11")}>
                <Avatar name={m.n} size={72} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "1rem", color: DK }}>{m.n}</div>
                      <div style={{ color: "#64748B", fontSize: "0.82rem", marginBottom: 6 }}>{m.r}</div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{m.sk.map(s => <Tag key={s} color={P}>{s}</Tag>)}<Tag color={A}>{m.f}</Tag></div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: P, fontSize: "1.2rem" }}>₹{m.p}<span style={{ fontSize: "0.75rem", color: "#64748B", fontWeight: 400 }}>/hr</span></div>
                      <div style={{ fontSize: "0.72rem", color: "#10B981", fontWeight: 600 }}>📅 {m.av}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 16, marginTop: 12, alignItems: "center" }}>
                    <span style={{ fontSize: "0.8rem", color: "#64748B" }}><Stars n={Math.round(m.rt)} /> {m.rt}</span>
                    <span style={{ fontSize: "0.8rem", color: "#64748B" }}>📹 {m.ss} sessions</span>
                    <button style={{ ...btnSt(), marginLeft: "auto", padding: "8px 18px", fontSize: "0.8rem" }}>Book Session</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* F11 */
function F11({ setFrame }: { setFrame: (f: string) => void }) {
  const [step, setStep] = useState(1);
  const [selDate, setSelDate] = useState<string|null>(null);
  const [selTime, setSelTime] = useState<string|null>(null);
  const [selDur, setSelDur] = useState<number|null>(null);
  const sC: Record<string,string> = {Completed:"#10B981",Pending:"#F59E0B",Approved:P,Rejected:"#EF4444",Scheduled:A,Cancelled:"#94A3B8",Waiting:S};
  const days = [{d:"Mon",dt:"21 Jul"},{d:"Tue",dt:"22 Jul"},{d:"Wed",dt:"23 Jul"},{d:"Thu",dt:"24 Jul"},{d:"Fri",dt:"25 Jul"}];
  const slots = ["09:00","10:30","12:00","14:00","15:30","17:00","18:30","20:00"];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 380px", gap: 28, alignItems: "start" }}>
        <div>
          <div style={cardSt({ padding: "28px", marginBottom: 20 })}>
            <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
              <div style={{ position: "relative" }}><Avatar name="Priya Sharma" size={100} /><div style={{ position: "absolute", bottom: 4, right: 4, width: 16, height: 16, background: "#10B981", borderRadius: "50%", border: "2.5px solid #fff" }} /></div>
              <div style={{ flex: 1 }}>
                <h2 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 4 }}>Priya Sharma</h2>
                <div style={{ color: "#64748B", marginBottom: 8 }}>SDE @ Google · IIT Delhi, B.Tech CS</div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["DSA","System Design","Java","Python","LeetCode"].map(s => <Tag key={s} color={P}>{s}</Tag>)}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 900, fontSize: "1.8rem", color: P }}>₹1,200<span style={{ fontSize: "0.85rem", color: "#64748B", fontWeight: 400 }}>/hr</span></div>
                <Stars n={5} /> <span style={{ fontSize: "0.8rem", color: "#64748B" }}>4.94 (248)</span>
                <div style={{ fontSize: "0.78rem", color: "#10B981", fontWeight: 600, marginTop: 6 }}>✅ Available Today</div>
              </div>
            </div>
            <div style={{ marginTop: 18, display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, borderTop: "1px solid rgba(0,0,0,.06)", paddingTop: 18 }}>
              {[["248","Sessions"],["186","Students"],["4.94","Rating"],["5 yrs","Experience"]].map(([n,l]) => <div key={l} style={{ textAlign: "center" }}><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: P, fontSize: "1.3rem" }}>{n}</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>{l}</div></div>)}
            </div>
          </div>
          <div style={cardSt({ padding: "22px", marginBottom: 16 })}>
            <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 10 }}>About</h4>
            <p style={{ color: "#475569", fontSize: "0.875rem", lineHeight: 1.75 }}>IIT Delhi CS graduate, SDE-3 at Google Hyderabad. Specializing in competitive programming, system design, and FAANG interview prep. 186+ students helped with 78% placement rate.</p>
          </div>
          <div style={cardSt({ padding: "22px" })}>
            <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 12 }}>Booking Status Tracker</h4>
            <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
              {Object.entries(sC).map(([s,c]) => <Tag key={s} color={c}>{s}</Tag>)}
            </div>
            {[{s:"Rahul K.",t:"DSA Session #8",d:"20 Jul 2025",st:"Completed"},{s:"Ananya M.",t:"Resume Review",d:"22 Jul 2025",st:"Scheduled"},{s:"Dev P.",t:"ML Guidance",d:"24 Jul 2025",st:"Pending"},{s:"Sneha I.",t:"Interview Prep",d:"25 Jul 2025",st:"Approved"},{s:"Kiran S.",t:"DSA Basics",d:"26 Jul 2025",st:"Waiting"}].map(b => (
              <div key={b.s+b.d} style={{ display: "flex", gap: 10, alignItems: "center", padding: "10px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                <Avatar name={b.s} size={32} />
                <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: "0.82rem", color: DK }}>{b.s} — {b.t}</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>{b.d}</div></div>
                <Tag color={sC[b.st]}>{b.st}</Tag>
              </div>
            ))}
          </div>
        </div>
        <div style={{ position: "sticky", top: 80 }}>
          <div style={cardSt({ padding: "24px" })}>
            <div style={{ display: "flex", gap: 4, marginBottom: 20, background: "#F1F5F9", padding: 4, borderRadius: 12 }}>
              {["Select Date","Choose Time","Confirm"].map((s,i) => <div key={s} onClick={() => setStep(i+1)} style={{ flex: 1, padding: "8px", textAlign: "center", borderRadius: 8, background: step===i+1?G1:"transparent", color: step===i+1?"#fff":"#94A3B8", fontWeight: 600, fontSize: "0.7rem", cursor: "pointer" }}>{i+1}. {s}</div>)}
            </div>
            {step === 1 && <>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12, fontSize: "0.9rem" }}>Select Date</div>
              <div style={{ display: "flex", gap: 8 }}>
                {days.map(({d,dt}) => <button key={dt} onClick={() => setSelDate(dt)} style={{ flex: 1, padding: "10px 4px", borderRadius: 10, border: selDate===dt?`2px solid ${P}`:"1.5px solid #E2E8F0", background: selDate===dt?`${P}12`:"#fff", cursor: "pointer", textAlign: "center" }}><div style={{ fontSize: "0.68rem", color: "#64748B", fontWeight: 600 }}>{d}</div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.8rem", color: selDate===dt?P:DK }}>{dt.split(" ")[0]}</div></button>)}
              </div>
              <div style={{ marginTop: 20 }}>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12, fontSize: "0.9rem" }}>Session Duration</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {[[30,"₹600"],[60,"₹1,200"],[90,"₹1,800"],[120,"₹2,400"]].map(([dur,price]) => <button key={dur} onClick={() => setSelDur(dur as number)} style={{ padding: "10px", borderRadius: 10, border: selDur===dur?`2px solid ${P}`:"1.5px solid #E2E8F0", background: selDur===dur?`${P}12`:"#fff", cursor: "pointer" }}><div style={{ fontWeight: 700, color: selDur===dur?P:DK, fontSize: "0.85rem" }}>{dur} min</div><div style={{ fontSize: "0.72rem", color: "#64748B" }}>{price}</div></button>)}
                </div>
              </div>
              <button onClick={() => setStep(2)} disabled={!selDate||!selDur} style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 16, padding: "12px", opacity: selDate&&selDur?1:0.5 }}>Next →</button>
            </>}
            {step === 2 && <>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12, fontSize: "0.9rem" }}>Available Slots — {selDate}</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 8 }}>
                {slots.map(t => <button key={t} onClick={() => setSelTime(t)} style={{ padding: "10px", borderRadius: 10, border: selTime===t?`2px solid ${P}`:"1.5px solid #E2E8F0", background: selTime===t?`${P}12`:"#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 600, fontSize: "0.82rem", color: selTime===t?P:DK, cursor: "pointer" }}>{t}</button>)}
              </div>
              <button onClick={() => setStep(3)} disabled={!selTime} style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 16, padding: "12px", opacity: selTime?1:0.5 }}>Confirm →</button>
            </>}
            {step === 3 && <>
              <div style={{ background: `${P}08`, borderRadius: 12, padding: 16, marginBottom: 16 }}>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 10 }}>Booking Summary</div>
                {[["Mentor","Priya Sharma"],["Date",selDate||""],["Time",selTime||""],["Duration",`${selDur} min`],["Amount",`₹${((selDur||60)/60*1200).toFixed(0)}`]].map(([k,v]) => <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: "0.82rem" }}><span style={{ color: "#64748B" }}>{k}</span><span style={{ fontWeight: 600, color: DK }}>{v}</span></div>)}
              </div>
              <button onClick={() => { setStep(1); setSelDate(null); setSelTime(null); setSelDur(null); }} style={{ ...btnSt(), width: "100%", justifyContent: "center", padding: "13px", fontSize: "0.95rem" }}>✅ Confirm & Pay</button>
              <button onClick={() => setStep(1)} style={{ ...btnOut(), width: "100%", marginTop: 8, padding: "10px", textAlign: "center" }}>← Go Back</button>
            </>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* F12 */
function F12({ setFrame }: { setFrame: (f: string) => void }) {
  const [mic, setMic] = useState(true);
  const [chat, setChat] = useState(false);
  return (
    <div style={{ background: "#0A0A0F", minHeight: "100vh", display: "flex", flexDirection: "column", color: "#fff" }}>
      <div style={{ background: "rgba(255,255,255,0.05)", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,.06)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><div style={{ width: 10, height: 10, background: "#10B981", borderRadius: "50%", boxShadow: "0 0 8px #10B981" }} /><span style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700 }}>Live Session — DSA Interview Prep</span></div>
        <div style={{ display: "flex", gap: 16, fontSize: "0.82rem", color: "#94A3B8" }}><span>⏱ 00:42:18</span><span>👁 2 participants</span><span style={{ color: "#EF4444", fontWeight: 600 }}>● REC</span></div>
      </div>
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: chat?"1fr 360px":"1fr", gap: 16, padding: 16 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ background: "#1a1a2e", borderRadius: 20, height: 400, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", inset: 0, background: `linear-gradient(135deg,${P}30,${S}20)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "5rem" }}>👩‍💻</div>
            <div style={{ position: "absolute", top: 16, left: 16, ...pillSt(P), background: `${P}cc` }}>Priya Sharma (Mentor)</div>
            <div style={{ position: "absolute", bottom: 16, right: 16, width: 140, height: 90, background: "#2a2a3e", borderRadius: 10, border: `2px solid ${P}60`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "2.5rem" }}>👨‍🎓</div>
          </div>
          <div style={{ background: "#fff", borderRadius: 16, height: 220, display: "flex", alignItems: "center", justifyContent: "center", border: `2px dashed ${P}40` }}>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: "2rem", marginBottom: 8 }}>🖥️</div><div style={{ color: "#64748B", fontSize: "0.85rem" }}>Shared Screen / Code Editor</div><div style={{ fontFamily: "'Poppins',sans-serif", color: DK, fontWeight: 700, fontSize: "1rem", marginTop: 6 }}>LeetCode #234 — Palindrome Linked List</div></div>
          </div>
          <div style={{ background: "rgba(255,255,255,.06)", borderRadius: 16, padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "center", gap: 14 }}>
            {[{ic:mic?"🎤":"🔇",l:mic?"Mute":"Unmute",a:()=>setMic(!mic),on:mic},{ic:"📷",l:"Video",a:()=>{},on:true},{ic:"🖥️",l:"Share",a:()=>{},on:false},{ic:"✏️",l:"Whiteboard",a:()=>{},on:false},{ic:"💬",l:"Chat",a:()=>setChat(!chat),on:chat},{ic:"⏺",l:"Record",a:()=>{},on:false}].map(({ic,l,a,on}) => (
              <button key={l} onClick={a} style={{ background: on?`${P}33`:"rgba(255,255,255,0.08)", border: on?`1.5px solid ${P}`:"1.5px solid rgba(255,255,255,.1)", borderRadius: 12, padding: "10px 14px", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, color: "#fff", minWidth: 56 }}>
                <span style={{ fontSize: "1.1rem" }}>{ic}</span><span style={{ fontSize: "0.6rem" }}>{l}</span>
              </button>
            ))}
            <div style={{ flex: 1 }} />
            <button onClick={() => setFrame("F06")} style={{ background: "#EF4444", border: "none", borderRadius: 12, padding: "12px 20px", color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, cursor: "pointer" }}>End Call</button>
          </div>
        </div>
        {chat && (
          <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 16, border: "1px solid rgba(255,255,255,.08)", display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "16px", borderBottom: "1px solid rgba(255,255,255,.06)", fontFamily: "'Poppins',sans-serif", fontWeight: 700 }}>💬 Chat</div>
            <div style={{ flex: 1, padding: "12px", display: "flex", flexDirection: "column", gap: 10 }}>
              {[{from:"Priya",msg:"Let's walk through the two-pointer approach.",time:"4:21 PM"},{from:"You",msg:"Should we use slow and fast pointers?",time:"4:23 PM"},{from:"Priya",msg:"Exactly! Fast moves 2x speed, slow 1x...",time:"4:24 PM"}].map((m,i) => (
                <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: m.from==="You"?"flex-end":"flex-start" }}>
                  <div style={{ maxWidth: "80%", background: m.from==="You"?P:"rgba(255,255,255,0.08)", borderRadius: 12, padding: "8px 12px", fontSize: "0.78rem", color: m.from==="You"?"#fff":"#E2E8F0" }}>{m.msg}</div>
                  <div style={{ fontSize: "0.62rem", color: "#475569", marginTop: 3 }}>{m.from} · {m.time}</div>
                </div>
              ))}
            </div>
            <div style={{ padding: "12px", borderTop: "1px solid rgba(255,255,255,.06)", display: "flex", gap: 8 }}>
              <input style={{ flex: 1, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 10, padding: "8px 12px", color: "#fff", fontSize: "0.8rem", outline: "none" }} placeholder="Type..." />
              <button style={{ background: P, border: "none", borderRadius: 10, padding: "8px 14px", cursor: "pointer", color: "#fff" }}>➤</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* F13 */
function F13({ setFrame }: { setFrame: (f: string) => void }) {
  const assignments = [
    {t:"Binary Trees – Problem Set #4",m:"Priya Sharma",d:"Tomorrow, 11:59 PM",st:"Pending",p:"High"},
    {t:"Linear Regression – Report",m:"Arjun Mehta",d:"In 3 days",st:"In Progress",p:"Medium"},
    {t:"Research Proposal – First Draft",m:"Dr. Kavita Nair",d:"In 7 days",st:"Pending",p:"Low"},
    {t:"VLSI Circuit Design – Lab Report",m:"Rahul Gupta",d:"Completed",st:"Completed",p:"Done",fb:"Excellent work! Grade: A+"},
  ];
  const pC: Record<string,string> = {High:"#EF4444",Medium:"#F59E0B",Low:"#10B981",Done:P};
  const sC: Record<string,string> = {Completed:"#10B981","In Progress":A,Pending:"#F59E0B"};
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ marginBottom: 28 }}><div style={{ ...pillSt(P), display: "inline-block", marginBottom: 10 }}>📋 Assignments</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Your Assignments</h2></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {assignments.map(a => (
              <div key={a.t} style={{ background: "#fff", borderRadius: 16, padding: "20px 22px", boxShadow: SHADOW }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.95rem", color: DK, marginBottom: 4 }}>{a.t}</div><div style={{ fontSize: "0.78rem", color: "#64748B" }}>by {a.m}</div></div>
                  <div style={{ display: "flex", gap: 8 }}><Tag color={pC[a.p]}>{a.p}</Tag><Tag color={sC[a.st]||P}>{a.st}</Tag></div>
                </div>
                <div style={{ fontSize: "0.78rem", color: a.st==="Completed"?"#10B981":"#EF4444", fontWeight: 600, marginBottom: 10 }}>📅 {a.d}</div>
                {(a as any).fb && <div style={{ fontSize: "0.78rem", color: "#10B981", background: "#10B98110", padding: "6px 10px", borderRadius: 8, marginBottom: 12 }}>💬 {(a as any).fb}</div>}
                {a.st !== "Completed" && <div style={{ background: `${P}06`, border: `1.5px dashed ${P}30`, borderRadius: 10, padding: "14px", textAlign: "center" }}><div style={{ fontSize: "0.8rem", color: "#64748B", marginBottom: 10 }}>📤 Drag & drop files or click to upload</div><button style={{ ...btnSt(), padding: "7px 18px", fontSize: "0.78rem" }}>📎 Submit Assignment</button></div>}
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>Progress</div>
              {[["Completed",8,"#10B981"],["In Progress",2,A],["Pending",4,"#F59E0B"],["Overdue",1,"#EF4444"]].map(([l,n,c]) => (
                <div key={l as string} style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: "0.8rem" }}><span style={{ color: "#475569", fontWeight: 600 }}>{l}</span><span style={{ fontWeight: 700, color: c as string }}>{n}</span></div>
                  <div style={{ height: 6, background: "#F1F5F9", borderRadius: 3 }}><div style={{ width: `${(n as number)/15*100}%`, height: "100%", background: c as string, borderRadius: 3 }} /></div>
                </div>
              ))}
            </div>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 12 }}>Recent Feedback</div>
              {[{m:"Priya S.",f:"Great approach on recursion! Try O(n) space.",g:"A-"},{m:"Arjun M.",f:"Add confusion matrix next time.",g:"B+"}].map(fb => (
                <div key={fb.m} style={{ padding: "10px 12px", background: `${P}06`, borderRadius: 10, marginBottom: 10, borderLeft: `3px solid ${P}` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}><span style={{ fontWeight: 600, fontSize: "0.78rem", color: DK }}>{fb.m}</span><span style={{ fontWeight: 800, color: "#10B981" }}>{fb.g}</span></div>
                  <p style={{ fontSize: "0.75rem", color: "#475569", lineHeight: 1.5, margin: 0 }}>{fb.f}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* F14 */
function F14({ setFrame }: { setFrame: (f: string) => void }) {
  const groups = [
    {n:"AI for Healthcare Research Group",f:"CS + Biotech",mem:24,pap:8,active:true,desc:"Applying ML/DL techniques to medical image analysis, drug discovery, and clinical decision support."},
    {n:"Quantum Computing Study Circle",f:"Physics + CS",mem:18,pap:4,active:true,desc:"Exploring quantum algorithms, error correction, and near-term quantum advantage applications."},
    {n:"Sustainable Energy Systems Lab",f:"Civil + EE",mem:31,pap:12,active:true,desc:"Research on solar microgrids, smart building systems, and renewable energy integration."},
    {n:"Bioinformatics & Genomics Hub",f:"Life Sciences",mem:15,pap:6,active:false,desc:"Sequence analysis, protein structure prediction, and CRISPR-Cas9 application research."},
  ];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32 }}>
          <div><div style={{ ...pillSt(A), display: "inline-block", marginBottom: 10 }}>🔬 Research Groups</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Collaborative Research Community</h2><p style={{ color: "#64748B" }}>Join groups, share papers, collaborate with peers</p></div>
          <button style={{ ...btnSt(), padding: "10px 20px" }}>+ Create Group</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 22 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {groups.map(g => (
              <div key={g.n} style={{ background: "#fff", borderRadius: 18, padding: "22px 24px", boxShadow: SHADOW }}>
                <div style={{ display: "flex", gap: 8, marginBottom: 8 }}><Tag color={A}>{g.f}</Tag><Tag color={g.active?"#10B981":"#64748B"}>{g.active?"Active":"Closed"}</Tag></div>
                <h3 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 8, fontSize: "1rem" }}>{g.n}</h3>
                <p style={{ color: "#64748B", fontSize: "0.82rem", lineHeight: 1.6, marginBottom: 14 }}>{g.desc}</p>
                <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                  <div style={{ display: "flex" }}>{[...Array(Math.min(4,g.mem))].map((_,i) => <div key={i} style={{ width: 28, height: 28, borderRadius: "50%", background: [P,S,A,"#F59E0B"][i]+"60", border: "2px solid #fff", marginLeft: i?-8:0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.65rem", color: "#fff", fontWeight: 700 }}>{["P","A","R","K"][i]}</div>)}</div>
                  <span style={{ fontSize: "0.78rem", color: "#64748B" }}>👥 {g.mem} members · 📄 {g.pap} papers</span>
                  <div style={{ flex: 1 }} />
                  {g.active && <button style={{ ...btnSt(), padding: "7px 14px", fontSize: "0.78rem" }}>Join</button>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>My Groups</div>
              {[{n:"AI for Healthcare",r:"Member",a:"2h ago"},{n:"Quantum Computing",r:"Admin",a:"Yesterday"}].map(g => (
                <div key={g.n} style={{ display: "flex", gap: 10, alignItems: "center", padding: "8px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                  <div style={{ width: 36, height: 36, background: `${A}20`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>🔬</div>
                  <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: "0.78rem", color: DK }}>{g.n}</div><div style={{ fontSize: "0.68rem", color: "#64748B" }}>{g.r} · {g.a}</div></div>
                </div>
              ))}
            </div>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>Recent Papers</div>
              {[{t:"Transformer Models in Drug Discovery",au:"Priya S., Ananya M.",d:"Jul 2025"},{t:"Quantum Error Correction Survey",au:"Dev P., Rahul K.",d:"Jun 2025"}].map(p => (
                <div key={p.t} style={{ padding: "8px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                  <div style={{ fontWeight: 600, fontSize: "0.78rem", color: DK, lineHeight: 1.4, marginBottom: 3 }}>{p.t}</div>
                  <div style={{ fontSize: "0.68rem", color: "#64748B" }}>{p.au} · {p.d}</div>
                </div>
              ))}
              <button style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 12, padding: "8px", fontSize: "0.78rem" }}>Upload Paper</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* F15 */
function F15({ setFrame }: { setFrame: (f: string) => void }) {
  const [sec, setSec] = useState("Personal Info");
  const sections = ["Personal Info","Education","Experience","Projects","Skills","Certifications","Preview"];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}><div style={{ ...pillSt(S), display: "inline-block", marginBottom: 10 }}>📄 Resume Builder</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Build a Professional Resume in Minutes</h2></div>
        <div style={{ display: "flex", gap: 2, marginBottom: 28, background: "#fff", borderRadius: 14, padding: 4, boxShadow: SHADOW }}>
          {sections.map((s,i) => <button key={s} onClick={() => setSec(s)} style={{ flex: 1, padding: "9px 4px", borderRadius: 10, border: "none", background: sec===s?G1:"transparent", color: sec===s?"#fff":"#64748B", fontWeight: 600, fontSize: "0.72rem", cursor: "pointer" }}>{["👤","🎓","💼","🚀","🛠","🏆","👁"][i]} {s}</button>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 24 }}>
          <div style={cardSt({ padding: "24px" })}>
            <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 20 }}>📝 {sec}</h4>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {[{l:"Full Name",p:"Rahul Kumar"},{l:"Email",p:"rahul@example.com",full:true},{l:"Phone",p:"+91 98765 43210"},{l:"City",p:"Delhi, India"},{l:"LinkedIn URL",p:"linkedin.com/in/rahul",full:true},{l:"GitHub / Portfolio",p:"github.com/rahul",full:true}].map(f => (
                <div key={f.l} style={{ gridColumn: (f as any).full?"1/-1":"auto" }}>
                  <label style={{ display: "block", marginBottom: 5, fontWeight: 600, fontSize: "0.78rem", color: DK }}>{f.l}</label>
                  <input style={inpSt()} placeholder={f.p} />
                </div>
              ))}
              <div style={{ gridColumn: "1/-1" }}><label style={{ display: "block", marginBottom: 5, fontWeight: 600, fontSize: "0.78rem", color: DK }}>Professional Summary</label><textarea style={{ ...inpSt(), minHeight: 80, resize: "vertical" }} placeholder="Fresher B.Tech CS student passionate about..." /></div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button style={{ ...btnOut(), flex: 1, padding: "10px" }}>← Back</button>
              <button style={{ ...btnSt(), flex: 2, justifyContent: "center", padding: "10px" }}>Save & Next →</button>
            </div>
          </div>
          <div style={cardSt({ padding: "24px" })}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>👁 Live Preview</div>
              <div style={{ display: "flex", gap: 8 }}><button style={{ ...btnOut(), padding: "5px 12px", fontSize: "0.72rem" }}>📄 PDF</button><button style={{ ...btnSt(), padding: "5px 12px", fontSize: "0.72rem" }}>Share</button></div>
            </div>
            <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 8, padding: 16, fontSize: "0.72rem", lineHeight: 1.6 }}>
              <div style={{ borderBottom: `3px solid ${P}`, paddingBottom: 10, marginBottom: 10 }}>
                <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 900, fontSize: "1.1rem", color: DK }}>RAHUL KUMAR</div>
                <div style={{ color: "#64748B" }}>B.Tech CS, DTU · rahul@example.com · +91 98765 43210</div>
              </div>
              {["EDUCATION","SKILLS","PROJECTS","EXPERIENCE"].map(s => <div key={s} style={{ marginBottom: 10 }}><div style={{ fontWeight: 700, color: P, fontSize: "0.72rem", borderBottom: "1px solid #E2E8F0", marginBottom: 5 }}>{s}</div><div style={{ color: "#94A3B8", fontStyle: "italic" }}>Fill in above to see preview...</div></div>)}
            </div>
            <div style={{ marginTop: 12, padding: "10px 14px", background: `${A}10`, borderRadius: 10, borderLeft: `3px solid ${A}` }}>
              <div style={{ fontSize: "0.75rem", fontWeight: 700, color: A, marginBottom: 4 }}>💡 AI Suggestion</div>
              <div style={{ fontSize: "0.72rem", color: "#475569" }}>Add quantifiable achievements and start bullets with action verbs for better ATS scores.</div>
            </div>
            <button style={{ ...btnSt(), width: "100%", justifyContent: "center", marginTop: 12, padding: "10px" }}>Request Mentor Review</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* F16 */
function F16({ setFrame }: { setFrame: (f: string) => void }) {
  const companies = [{n:"Google",l:"🔵",r:"SWE Intern",c:"7.5+",d:"Aug 15, 2025",s:"Open"},{n:"Microsoft",l:"🟦",r:"SDE-1",c:"7.0+",d:"Aug 22, 2025",s:"Open"},{n:"Infosys",l:"🔷",r:"Systems Engineer",c:"6.0+",d:"Sep 1, 2025",s:"Open"},{n:"Amazon",l:"🟠",r:"SDE-1 (L4)",c:"7.5+",d:"Jul 31, 2025",s:"Closing Soon"}];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ ...pillSt(P), display: "inline-block", marginBottom: 12 }}>💼 Placement</div>
        <h2 style={{ fontFamily: "'Poppins',sans-serif", marginBottom: 4 }}>Placement Hub — Campus Recruiting 2025</h2>
        <p style={{ color: "#64748B", marginBottom: 28 }}>Track drives, prepare for interviews, and get placed</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 22 }}>
          <div>
            <div style={cardSt({ padding: "22px", marginBottom: 20 })}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}><h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK }}>🏢 Active Placement Drives</h4><button style={{ ...btnSt(), padding: "6px 14px", fontSize: "0.78rem" }}>Set Alerts</button></div>
              {companies.map(c => (
                <div key={c.n} style={{ display: "flex", gap: 14, alignItems: "center", padding: "12px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                  <div style={{ width: 44, height: 44, background: "#F1F5F9", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem" }}>{c.l}</div>
                  <div style={{ flex: 1 }}><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>{c.n}</div><div style={{ fontSize: "0.78rem", color: "#64748B" }}>{c.r} · Min CGPA: {c.c} · Deadline: {c.d}</div></div>
                  <Tag color={c.s==="Closing Soon"?"#EF4444":"#10B981"}>{c.s}</Tag>
                  <button style={{ ...btnSt(), padding: "6px 16px", fontSize: "0.78rem" }}>Apply →</button>
                </div>
              ))}
            </div>
            <div style={cardSt({ padding: "22px" })}>
              <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 14 }}>🎙️ Interview Preparation</h4>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                {[["Technical DSA","250+ curated problems","💻",P],["System Design","Architecture scenarios","🏗️",S],["HR Questions","Top 50 behavioral Q&A","🤝",A],["Mock Interviews","Book with mentor","🎙️","#F59E0B"]].map(([t,d,ic,c]) => (
                  <div key={t} style={{ background: `${c}08`, border: `1.5px solid ${c}20`, borderRadius: 12, padding: "14px" }}>
                    <div style={{ fontSize: "1.5rem", marginBottom: 6 }}>{ic}</div>
                    <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.85rem", color: DK, marginBottom: 3 }}>{t}</div>
                    <div style={{ fontSize: "0.72rem", color: "#64748B", marginBottom: 8 }}>{d}</div>
                    <button onClick={() => setFrame("F11")} style={{ background: `${c}18`, border: "none", borderRadius: 8, padding: "5px 10px", color: c as string, fontWeight: 600, fontSize: "0.72rem", cursor: "pointer" }}>Start →</button>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={cardSt({ padding: "20px" })}>
              <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK, marginBottom: 14 }}>Placement Readiness</div>
              {[["🧮 Aptitude & Reasoning",80],["💻 DSA (200 problems)",55],["🏗️ System Design Basics",30],["🤝 HR & Behavioral",90]].map(([l,n]) => (
                <div key={l as string} style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: "0.78rem" }}><span>{l}</span><span style={{ fontWeight: 700, color: (n as number)>=70?"#10B981":(n as number)>=40?"#F59E0B":"#EF4444" }}>{n}%</span></div>
                  <div style={{ height: 6, background: "#F1F5F9", borderRadius: 3 }}><div style={{ width: `${n}%`, height: "100%", background: (n as number)>=70?"#10B981":(n as number)>=40?"#F59E0B":"#EF4444", borderRadius: 3 }} /></div>
                </div>
              ))}
            </div>
            <div style={{ ...cardSt({ padding: "20px" }), background: G2, border: "none" }}>
              <div style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, marginBottom: 10 }}>🎯 Success Stories</div>
              {[{n:"Priya R.",p:"Google · ₹42 LPA"},{n:"Arjun S.",p:"Microsoft · ₹35 LPA"},{n:"Kavita M.",p:"Amazon · ₹28 LPA"}].map(s => (
                <div key={s.n} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}><Avatar name={s.n} size={28} /><div><div style={{ color: "#fff", fontSize: "0.78rem", fontWeight: 600 }}>{s.n}</div><div style={{ color: "rgba(255,255,255,.7)", fontSize: "0.68rem" }}>{s.p}</div></div></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* F17 */
function F17({ setFrame }: { setFrame: (f: string) => void }) {
  const certs = [
    {t:"Data Structures & Algorithms – Complete Mastery",m:"Priya Sharma",d:"June 15, 2025",id:"SSH-DSA-2025-0483",st:"Issued",sc:94},
    {t:"Machine Learning Fundamentals",m:"Arjun Mehta",d:"May 2, 2025",id:"SSH-ML-2025-0312",st:"Issued",sc:88},
    {t:"Research Methodology & Academic Writing",m:"Dr. Kavita Nair",d:"Pending",id:"SSH-RM-2025-PEND",st:"In Progress",sc:null},
  ];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}><div style={{ ...pillSt("#F59E0B"), display: "inline-block", marginBottom: 12 }}>🏆 Certificates</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>Your Achievements</h2><p style={{ color: "#64748B" }}>Blockchain-verified certificates from top graduate mentors</p></div>
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          {certs.map(c => (
            <div key={c.id} style={{ background: "#fff", borderRadius: 20, overflow: "hidden", boxShadow: SHADOW_LG, display: "grid", gridTemplateColumns: "320px 1fr" }}>
              <div style={{ background: c.st==="Issued"?G1:"linear-gradient(135deg,#94A3B8,#64748B)", padding: "32px 28px", display: "flex", flexDirection: "column", justifyContent: "space-between", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: -30, right: -30, width: 140, height: 140, border: "2px solid rgba(255,255,255,0.15)", borderRadius: "50%" }} />
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20 }}><div style={{ width: 32, height: 32, background: "rgba(255,255,255,.2)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>🎓</div><span style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.85rem" }}>ShareSkill Hub</span></div>
                  <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,.7)", marginBottom: 8, letterSpacing: "0.06em" }}>CERTIFICATE OF COMPLETION</div>
                  <div style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: "0.9rem", lineHeight: 1.4, marginBottom: 14 }}>{c.t}</div>
                  {c.sc && <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 8, padding: "6px 12px", display: "inline-block" }}><span style={{ color: "#fff", fontWeight: 700 }}>Score: {c.sc}%</span></div>}
                </div>
                <div><div style={{ color: "rgba(255,255,255,.7)", fontSize: "0.65rem", marginBottom: 4 }}>Certificate ID</div><div style={{ color: "#fff", fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.72rem" }}>{c.id}</div></div>
              </div>
              <div style={{ padding: "28px" }}>
                <Tag color={c.st==="Issued"?"#10B981":"#F59E0B"}>{c.st}</Tag>
                <div style={{ marginTop: 12, fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>{c.t}</div>
                <div style={{ color: "#64748B", fontSize: "0.82rem", marginTop: 4 }}>Mentor: {c.m}</div>
                <div style={{ color: "#64748B", fontSize: "0.78rem" }}>Issued: {c.d}</div>
                <div style={{ marginTop: 20 }}>
                  {c.st==="Issued" ? (
                    <div style={{ display: "flex", gap: 10 }}>
                      <button style={{ ...btnSt(), padding: "9px 20px", fontSize: "0.82rem" }}>📥 Download PDF</button>
                      <button style={{ ...btnOut(), padding: "9px 16px", fontSize: "0.82rem" }}>🔗 Share</button>
                      <button style={{ ...btnOut(), padding: "9px 16px", fontSize: "0.82rem" }}>✅ Verify</button>
                    </div>
                  ) : (
                    <div>
                      <div style={{ background: "#F1F5F9", borderRadius: 8, padding: "10px 14px", marginBottom: 10 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.78rem", marginBottom: 6 }}><span style={{ color: "#64748B" }}>Course Progress</span><span style={{ fontWeight: 700, color: P }}>62%</span></div>
                        <div style={{ height: 6, background: "#E2E8F0", borderRadius: 3 }}><div style={{ width: "62%", height: "100%", background: G1, borderRadius: 3 }} /></div>
                      </div>
                      <button onClick={() => setFrame("F09")} style={{ ...btnSt(), padding: "9px 20px", fontSize: "0.82rem" }}>Continue Course →</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* F18 */
function F18({ setFrame }: { setFrame: (f: string) => void }) {
  const [active, setActive] = useState("Priya Sharma");
  const convos = [{n:"Priya Sharma",l:"Great work on that problem! 🎉",t:"2m ago",u:3,on:true},{n:"Arjun Mehta",l:"Check the dataset I shared.",t:"1h ago",u:0,on:true},{n:"Dr. Kavita Nair",l:"Please submit by Friday.",t:"Yesterday",u:1,on:false}];
  const msgs = [{f:"Priya",m:"Hi! Ready for today session?",t:"3:58 PM"},{f:"You",m:"Yes! I have been practicing the two-pointer technique.",t:"4:01 PM"},{f:"Priya",m:"Perfect! Let us start with Problem #234 – Palindrome Linked List.",t:"4:02 PM"},{f:"You",m:"Should we use slow and fast pointers here?",t:"4:05 PM"},{f:"Priya",m:"Exactly! Initialize both at head, fast moves 2x speed...",t:"4:07 PM"},{f:"Priya",m:"Great work on that problem! 🎉 Try Problem #876 as homework.",t:"4:28 PM"}];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "60px 0 0" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", height: "calc(100vh - 60px)", display: "grid", gridTemplateColumns: "300px 1fr" }}>
        <div style={{ background: "#fff", borderRight: "1px solid #E2E8F0", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "16px" }}><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, color: DK, marginBottom: 12 }}>💬 Messages</div><input style={{ ...inpSt(), borderRadius: 30 }} placeholder="🔍 Search..." /></div>
          <div style={{ flex: 1, overflowY: "auto" }}>
            {convos.map(c => (
              <div key={c.n} onClick={() => setActive(c.n)} style={{ padding: "12px 16px", cursor: "pointer", background: active===c.n?`${P}08`:"transparent", borderLeft: active===c.n?`3px solid ${P}`:"3px solid transparent", display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{ position: "relative" }}><Avatar name={c.n} size={40} />{c.on && <div style={{ position: "absolute", bottom: 1, right: 1, width: 10, height: 10, background: "#10B981", borderRadius: "50%", border: "2px solid #fff" }} />}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ fontWeight: 700, fontSize: "0.85rem", color: DK }}>{c.n}</span><span style={{ fontSize: "0.68rem", color: "#94A3B8" }}>{c.t}</span></div>
                  <div style={{ fontSize: "0.75rem", color: "#64748B", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.l}</div>
                </div>
                {c.u > 0 && <div style={{ width: 18, height: 18, background: P, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.6rem", color: "#fff", fontWeight: 700, flexShrink: 0 }}>{c.u}</div>}
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", background: "#FAFBFC" }}>
          <div style={{ padding: "14px 20px", background: "#fff", borderBottom: "1px solid #E2E8F0", display: "flex", gap: 12, alignItems: "center" }}>
            <Avatar name={active} size={38} /><div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: DK }}>{active}</div><div style={{ fontSize: "0.72rem", color: "#10B981" }}>● Online</div></div>
            <div style={{ flex: 1 }} />
            <button onClick={() => setFrame("F12")} style={{ ...btnSt(), padding: "7px 14px", fontSize: "0.78rem" }}>📹 Video Call</button>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: 12 }}>
            {msgs.map((m,i) => (
              <div key={i} style={{ display: "flex", justifyContent: m.f==="You"?"flex-end":"flex-start", alignItems: "flex-end", gap: 8 }}>
                {m.f !== "You" && <Avatar name={m.f} size={28} />}
                <div style={{ maxWidth: "60%" }}>
                  <div style={{ background: m.f==="You"?G1:"#fff", color: m.f==="You"?"#fff":DK, borderRadius: m.f==="You"?"16px 16px 0 16px":"16px 16px 16px 0", padding: "10px 14px", fontSize: "0.82rem", lineHeight: 1.55, boxShadow: SHADOW }}>{m.m}</div>
                  <div style={{ fontSize: "0.62rem", color: "#94A3B8", marginTop: 3, textAlign: m.f==="You"?"right":"left" }}>{m.t}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ padding: "14px 20px", background: "#fff", borderTop: "1px solid #E2E8F0", display: "flex", gap: 10 }}>
            <button style={{ background: "none", border: "none", fontSize: "1.2rem", cursor: "pointer" }}>📎</button>
            <input style={{ ...inpSt(), flex: 1, borderRadius: 30 }} placeholder="Type a message..." />
            <button style={{ ...btnSt(), padding: "10px 16px", borderRadius: 30 }}>➤</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* F19 */
function F19({ setFrame }: { setFrame: (f: string) => void }) {
  const notifs = [
    {ic:"📹",t:"Session Confirmed",b:"Priya Sharma confirmed your DSA session for Today 4:00 PM.",tm:"Just now",c:P,u:true},
    {ic:"📋",t:"Assignment Due Tomorrow",b:"Binary Trees Problem Set #4 is due tomorrow at 11:59 PM.",tm:"1h ago",c:"#EF4444",u:true},
    {ic:"💬",t:"New Message from Arjun Mehta",b:"Check the ML dataset I shared in our conversation.",tm:"2h ago",c:S,u:true},
    {ic:"🏆",t:"Certificate Issued!",b:"Your DSA Mastery certificate has been issued. Download it now.",tm:"Yesterday",c:"#F59E0B",u:false},
    {ic:"🔬",t:"New Research Paper Shared",b:"AI for Healthcare group shared a new paper.",tm:"Yesterday",c:A,u:false},
    {ic:"💼",t:"Amazon Placement Drive",b:"Amazon is hiring! Application deadline: July 31. Apply now.",tm:"2 days ago",c:"#F59E0B",u:false},
  ];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 760, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}><div><div style={{ ...pillSt(P), display: "inline-block", marginBottom: 10 }}>🔔 Notifications</div><h2 style={{ fontFamily: "'Poppins',sans-serif" }}>All Notifications</h2></div><button style={{ ...btnOut(), padding: "7px 14px", fontSize: "0.78rem" }}>Mark all read</button></div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {notifs.map((n,i) => (
            <div key={i} style={{ background: n.u?`${n.c}06`:"#fff", borderRadius: 14, padding: "16px 18px", boxShadow: SHADOW, border: n.u?`1.5px solid ${n.c}20`:"1.5px solid transparent", display: "flex", gap: 14, alignItems: "flex-start", cursor: "pointer" }}>
              <div style={{ width: 44, height: 44, background: `${n.c}18`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.3rem", flexShrink: 0 }}>{n.ic}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 700, fontSize: "0.9rem", color: DK }}>{n.t}</div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}><span style={{ fontSize: "0.7rem", color: "#94A3B8" }}>{n.tm}</span>{n.u && <div style={{ width: 8, height: 8, background: n.c, borderRadius: "50%" }} />}</div>
                </div>
                <div style={{ color: "#64748B", fontSize: "0.82rem", lineHeight: 1.5 }}>{n.b}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* F20 */
function F20({ setFrame }: { setFrame: (f: string) => void }) {
  const [tab, setTab] = useState("Profile");
  const tabs = ["Profile","Account","Notifications","Privacy","Billing","Appearance"];
  return (
    <div style={{ background: BG, minHeight: "100vh", padding: "80px 24px 40px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ ...pillSt(P), display: "inline-block", marginBottom: 12 }}>👤 Profile & Settings</div>
        <h2 style={{ fontFamily: "'Poppins',sans-serif", marginBottom: 24 }}>Your Account</h2>
        <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 24 }}>
          <div style={cardSt({ padding: "12px" })}>
            {tabs.map((t,i) => <button key={t} onClick={() => setTab(t)} style={{ width: "100%", padding: "10px 14px", border: "none", background: tab===t?G1:"transparent", color: tab===t?"#fff":"#64748B", borderRadius: 10, fontWeight: 600, fontSize: "0.82rem", cursor: "pointer", textAlign: "left", marginBottom: 3 }}>{["👤","🔐","🔔","🛡","💳","🎨"][i]} {t}</button>)}
          </div>
          <div>
            {tab === "Profile" && (
              <div style={cardSt({ padding: "28px" })}>
                <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 24 }}>Public Profile</h4>
                <div style={{ display: "flex", gap: 20, alignItems: "center", marginBottom: 28, padding: "20px", background: `${P}06`, borderRadius: 16 }}>
                  <div style={{ position: "relative" }}><Avatar name="Rahul Kumar" size={80} /><button style={{ position: "absolute", bottom: 0, right: 0, width: 26, height: 26, background: P, border: "2.5px solid #fff", borderRadius: "50%", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem" }}>✏️</button></div>
                  <div><div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: "1.1rem", color: DK }}>Rahul Kumar</div><div style={{ color: "#64748B" }}>Fresher · B.Tech CS, Delhi Technical University</div><button style={{ ...btnOut(), marginTop: 8, padding: "5px 12px", fontSize: "0.72rem" }}>Upload Photo</button></div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  {[{l:"Full Name",v:"Rahul Kumar",f:false},{l:"Email",v:"rahul@example.com",f:false},{l:"Phone",v:"+91 98765 43210",f:false},{l:"City",v:"Delhi, India",f:false},{l:"University",v:"Delhi Technological University",f:true},{l:"LinkedIn URL",v:"linkedin.com/in/rahul",f:true}].map(fi => (
                    <div key={fi.l} style={{ gridColumn: fi.f?"1/-1":"auto" }}><label style={{ display: "block", marginBottom: 5, fontWeight: 600, fontSize: "0.78rem", color: DK }}>{fi.l}</label><input style={inpSt()} defaultValue={fi.v} /></div>
                  ))}
                  <div style={{ gridColumn: "1/-1" }}><label style={{ display: "block", marginBottom: 5, fontWeight: 600, fontSize: "0.78rem", color: DK }}>Bio</label><textarea style={{ ...inpSt(), minHeight: 80, resize: "vertical" }} defaultValue="B.Tech CS student passionate about AI/ML and competitive programming." /></div>
                </div>
                <div style={{ display: "flex", gap: 10, marginTop: 20 }}><button style={{ ...btnSt(), padding: "10px 24px" }}>Save Changes</button><button style={{ ...btnOut(), padding: "10px 18px" }}>Cancel</button></div>
              </div>
            )}
            {tab === "Notifications" && (
              <div style={cardSt({ padding: "28px" })}>
                <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 20 }}>Notification Preferences</h4>
                {[["Session Reminders","Get notified 30 min before your session",true],["Assignment Deadlines","Alerts for upcoming due dates",true],["New Messages","Notify when a mentor sends you a message",true],["Placement Drives","News about campus placements",true],["Research Updates","Activity in your research groups",false],["Marketing Emails","Tips, product updates, and offers",false]].map(([l,d,on]) => (
                  <div key={l as string} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
                    <div><div style={{ fontWeight: 600, fontSize: "0.85rem", color: DK }}>{l as string}</div><div style={{ fontSize: "0.75rem", color: "#64748B" }}>{d as string}</div></div>
                    <div style={{ width: 44, height: 24, background: on?P:"#CBD5E1", borderRadius: 12, position: "relative", cursor: "pointer" }}><div style={{ position: "absolute", top: 2, left: on?22:2, width: 20, height: 20, background: "#fff", borderRadius: "50%", boxShadow: "0 1px 4px rgba(0,0,0,.2)" }} /></div>
                  </div>
                ))}
              </div>
            )}
            {tab === "Appearance" && (
              <div style={cardSt({ padding: "28px" })}>
                <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 20 }}>Appearance & Theme</h4>
                <div style={{ marginBottom: 24 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.85rem", color: DK, marginBottom: 12 }}>Theme Mode</div>
                  <div style={{ display: "flex", gap: 12 }}>
                    {[["☀️","Light","#fff"],["🌙","Dark",DK],["💻","System","#F1F5F9"]].map(([ic,l,bg]) => (
                      <div key={l} style={{ flex: 1, border: l==="Light"?`2px solid ${P}`:"1.5px solid #E2E8F0", borderRadius: 12, padding: 14, textAlign: "center", cursor: "pointer", background: bg as string }}>
                        <div style={{ fontSize: "1.5rem", marginBottom: 4 }}>{ic}</div>
                        <div style={{ fontWeight: 600, fontSize: "0.8rem", color: l==="Dark"?"#fff":DK }}>{l}</div>
                        {l==="Light" && <Tag color={P}>Active</Tag>}
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: "0.85rem", color: DK, marginBottom: 12 }}>Accent Color</div>
                  <div style={{ display: "flex", gap: 10 }}>
                    {[P, S, A, "#10B981", "#F59E0B", "#EF4444"].map(c => <div key={c} style={{ width: 32, height: 32, background: c, borderRadius: "50%", cursor: "pointer", border: c===P?"3px solid rgba(0,0,0,.3)":"none", boxSizing: "border-box" }} />)}
                  </div>
                </div>
              </div>
            )}
            {["Account","Privacy","Billing"].includes(tab) && (
              <div style={cardSt({ padding: "40px", textAlign: "center" })}>
                <div style={{ fontSize: "3rem", marginBottom: 12 }}>{tab==="Account"?"🔐":tab==="Privacy"?"🛡️":"💳"}</div>
                <h4 style={{ fontFamily: "'Poppins',sans-serif", color: DK, marginBottom: 8 }}>{tab} Settings</h4>
                <p style={{ color: "#64748B", maxWidth: 300, margin: "0 auto" }}>This section is fully implemented in the PHP/MySQL backend.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ROOT */
export default function App() {
  const [frame, setFrame] = useState("F01");
  const comps: Record<string, React.ReactNode> = {
    F01: <F01 setFrame={setFrame} />, F02: <F02 setFrame={setFrame} />, F03: <F03 setFrame={setFrame} />,
    F04: <F04 setFrame={setFrame} />, F05: <F05 setFrame={setFrame} />, F06: <F06 setFrame={setFrame} />,
    F07: <F07 setFrame={setFrame} />, F08: <F08 setFrame={setFrame} />, F09: <F09 setFrame={setFrame} />,
    F10: <F10 setFrame={setFrame} />, F11: <F11 setFrame={setFrame} />, F12: <F12 setFrame={setFrame} />,
    F13: <F13 setFrame={setFrame} />, F14: <F14 setFrame={setFrame} />, F15: <F15 setFrame={setFrame} />,
    F16: <F16 setFrame={setFrame} />, F17: <F17 setFrame={setFrame} />, F18: <F18 setFrame={setFrame} />,
    F19: <F19 setFrame={setFrame} />, F20: <F20 setFrame={setFrame} />,
  };
  const showNav = !["F02","F03","F04","F05","F06","F12","F18"].includes(frame);
  const cf = FRAMES.find(f => f.id === frame);
  return (
    <div style={{ display: "flex", fontFamily: "'Inter',sans-serif" }}>
      <FrameNav current={frame} setFrame={setFrame} />
      <div style={{ flex: 1, minWidth: 0, marginLeft: 60 }}>
        {showNav && <Navbar setFrame={setFrame} />}
        <div style={{ paddingTop: showNav ? 60 : 0 }}>
          {comps[frame]}
        </div>
        <div style={{ position: "fixed", bottom: 70, right: 16, zIndex: 900, background: DK, color: "#fff", padding: "6px 14px", borderRadius: 20, fontSize: "0.7rem", fontWeight: 700, fontFamily: "'Poppins',sans-serif", boxShadow: "0 4px 12px rgba(0,0,0,.3)", display: "flex", alignItems: "center", gap: 6 }}>
          <span>{cf?.emoji}</span><span style={{ color: "#64748B" }}>{cf?.id}</span><span>{cf?.label}</span>
        </div>
        <div style={{ position: "fixed", bottom: 16, right: 16, zIndex: 900, display: "flex", gap: 8 }}>
          <button onClick={() => { const i=FRAMES.findIndex(f=>f.id===frame); if(i>0) setFrame(FRAMES[i-1].id); }} style={{ background: "rgba(255,255,255,0.9)", border: "1.5px solid #E2E8F0", borderRadius: 10, padding: "8px 16px", fontWeight: 700, fontSize: "0.8rem", cursor: "pointer", color: DK, backdropFilter: "blur(10px)" }}>← Prev</button>
          <button onClick={() => { const i=FRAMES.findIndex(f=>f.id===frame); if(i<FRAMES.length-1) setFrame(FRAMES[i+1].id); }} style={{ ...btnSt(), padding: "8px 16px", fontSize: "0.8rem" }}>Next →</button>
        </div>
      </div>
    </div>
  );
}
